# Zaonhe Ruby (zhruby)

 Converts Traditional Chinese passage to TeX-flavoured ruby and outputs PDF. 

 usage
