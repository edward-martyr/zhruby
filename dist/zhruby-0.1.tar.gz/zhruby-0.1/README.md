# yahwe_zaonhe TeX Ruby
 Convert Traditional Chinese passage to TeX-flavoured ruby
