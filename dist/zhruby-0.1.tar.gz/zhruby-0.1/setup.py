import setuptools

setuptools.setup(name='zhruby',
version='0.1',
description='Zaonhe Ruby. Output TeX and PDF with Shanghainese ruby from Chinese passages.',
url='#',
author='Edward Martyr',
author_email='edwardmartyr@outlook.com',
license='MIT',
packages=setuptools.find_packages()
)
